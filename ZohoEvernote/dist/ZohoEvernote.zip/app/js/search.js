$(document).ready(function(){
    $(".hello").on("click", function(e) {
      e.preventDefault();
        $("#searchPage").hide();
        $("#createNewPage").show();
    });
    $(".goToSearch").on("click", function(e) {
      e.preventDefault();
      $("#searchPage").show();
      $("#createNewPage").hide();
    }); 
   
});